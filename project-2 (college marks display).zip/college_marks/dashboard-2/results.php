<?php require "common.php";?>
<?php
session_start();
if($_SESSION['is_login']){
}
else{
 header("Location: ../adminstration/asministration.php");
}
$result=mysqli_query($con,"SELECT* from student_marks");
if(isset($_SESSION['true'])){
?>
         <table>
    <tr id="header">
            <th>S.NO</th>
            <th>Roll no</th>
            <th>Name</th>
            <th>Year</th>
            <th>Sem</th>
            <th>Maths</th>
            <th>Java</th>
            <th>Python</th>
            <th>Data Structures</th>
            <th>English</th>
            <th>GPA</th>
            <th>Select</th>
            <th>DELETE</th>
        </tr>
        <tr>
        <?php
         while($res=mysqli_fetch_array($result)){
             ?>
     <td><?php echo $res['id'];?></td>
     <td><?php echo $res['roll_no'];?></td>
     <td><?php echo $res['name'];?></td>
     <td><?php echo $_SESSION['year'];?></td>
     <td><?php echo $_SESSION['sem'];?></td>
     <td><?php echo $res['Maths'];?></td>
     <td><?php echo $res['java'];?></td>
     <td><?php echo $res['python'];?></td>
     <td><?php echo $res['data_structures'];?></td>
     <td><?php echo $res['english'];?></td>
     <td><?php echo $res['gpa'];?></td>
    <td>
        <input type="checkbox" name="keyToDelete" value="<?php echo $res['roll_no'];?>" required>
    </td>
    <td>
        <button> <a id="sumbit-button" href="delete.php?recordId=<?php echo $res['roll_no'];?>">submit</a></button>
    <!--<a id="deletebutton-5" href="delete.php?recordId=<?php echo $res['roll_no'];?>" value="delete" >submit</a>-->
    </td>
    </tr>
<?php
    unset ($_SESSION['true']);}
         }
?>

<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">

<div class="wrapper">
    <div class="sidebar">
        <h2>Rgukt</h2>
        <ul>
            <li><a href="dashboard.php" ><i class="fas fa-home"></i>Home</a></li>
            <li><a href="#"><i class="fas fa-user"></i>Profile</a></li>
            <li><a href="#"><i class="fas fa-address-card"></i>About</a></li>
            <li style="background-color:#594f8d;"><a href="#"><i class="fas fa-project-diagram"></i>Results</a></li>
            <li><a href="#"><i class="fas fa-blog"></i>Settings</a></li>
            <li><a href="#"><i class="fas fa-address-book"></i>Contact </a></li>
            <li><a href="logout_script.php"><i class="fas fa-map-pin"></i>logout</a></li>
        </ul> 
        
    </div>
    <div class="main_content">
        <div class="header" >Welcome</div>  
    </div>
    <div class="check">
        <h1 id="check-title">Students List</h1>
    </div>
    <div class="box">
    <form method="POST" action="../admin-students/confirm.php">
        <div class="form-group">
      <select name="year" class=" sem form-control" >
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
      </select>
      <select name="sem" class=" sem-2 form-control">
      <option value="sem1">1</option>
      <option value="sem2">2</option>     
    </select>
    <select name="view" class=" sem-3 form-control">
    <option value="">Compact View</option>
    <option value="">Grades view</option>
    </select>
        </div>
        </div>
        <button type="submit" name="submit" class="btn btn-success button" onclick="">Submit</button>
        <button type="submit" name="submit" class="btn btn-2 btn-success button" onclick=""><a id="fresh" href="../new-student/results.php">new student</button>
</form>
</div>
<div class="heading">
<h4 id="year">Select Year </h4>
<h4 id="sem">Select Sem </h4>
<h4 id="view">Select view </h4>
</div>