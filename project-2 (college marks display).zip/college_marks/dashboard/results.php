<?php require "common.php";?>
<?php
session_start();
if($_SESSION['is_login']){
}
else{
 header("Location: ../student/student.php");
}
$_roll_no= $_SESSION['roll_no'];
$query=("select * from student_marks where roll_no='$_roll_no'");
$result=mysqli_query($con,$query) or die(mysqli_error($con));
if(isset($_SESSION['true'])){
?>
         <table>
    <tr id="header">
            <th>S.NO</th>
            <th>Roll no</th>
            <th>Year</th>
            <th>Sem</th>
            <th>Maths</th>
            <th>Java</th>
            <th>Python</th>
            <th>Data Structures</th>
            <th>English</th>
            <th>GPA</th>
        </tr>
        <?php
         while($res=mysqli_fetch_array($result)){
     echo '<tr>';
     echo '<td>'.$res['id'].'</td>';
     echo '<td>'.$res['roll_no'].'</td>';
     echo '<td>'.$_SESSION['year'].'</td>';
     echo '<td>'.$_SESSION['sem'].'</td>';
     echo '<td>'.$res['Maths'].'</td>';
     echo '<td>'.$res['java'].'</td>';
     echo '<td>'.$res['python'].'</td>';
     echo '<td>'.$res['data_structures'].'</td>';
     echo '<td>'.$res['english'].'</td>';
     echo '<td>'.$res['gpa'].'</td>';
     echo '</tr>';
    }
    unset($_SESSION['true']);}
?>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">

<div class="wrapper">
    <div class="sidebar">
        <h2>Rgukt</h2>
        <ul>
            <li><a href="dashboard.php" ><i class="fas fa-home"></i>Home</a></li>
            <li><a href="#"><i class="fas fa-user"></i>Profile</a></li>
            <li><a href="#"><i class="fas fa-address-card"></i>About</a></li>
            <li style="background-color:#594f8d;"><a href="#"><i class="fas fa-project-diagram"></i>Results</a></li>
            <li><a href="#"><i class="fas fa-blog"></i>Settings</a></li>
            <li><a href="#"><i class="fas fa-address-book"></i>Contact </a></li>
            <li><a href="logout_script.php"><i class="fas fa-map-pin"></i>logout</a></li>
        </ul> 
        
    </div>
    <div class="main_content">
        <div class="header" >ALL the best</div>  
    </div>
    <div class="check">
        <h1 id="check-title">Check your results</h1>
    </div>
    <div class="box">
    <form method="POST" action="confirm.php">
        <div class="form-group">
      <select name="year" class=" sem form-control" >
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
      </select>
      <select name="sem" class=" sem-2 form-control">
      <option value="sem1">1</option>
      <option value="sem2">2</option>      
    </select>
    <select name="view" class=" sem-3 form-control">
    <option value="">Compact View</option>
    <option value="">Grades view</option>
    </select>
        </div>
        </div>
<input type="submit" name="submit" class="btn btn-success button" value="submit">
</form>
</div>
<h4 id="year">Select Year </h4>
<h4 id="sem">Select Sem </h4>
<h4 id="view">Select view </h4>